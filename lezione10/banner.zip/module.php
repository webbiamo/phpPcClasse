<?php

require('functions.php');

$towns=['Torino','Alessandria','Asti','Biella','Cuneo','Novara','Verbano-Cusio-Ossola','Vercelli'];

echo html_combo('citta',$towns,2);


