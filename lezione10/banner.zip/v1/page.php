<?php

require('banner.php');

// qui va il banner
echo get_banner($banners);




// contenuto
?>
<p> qui va il contenuto </p>