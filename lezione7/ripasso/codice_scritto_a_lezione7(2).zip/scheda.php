<?php

$filename = $_GET['file'] ??  '';

echo file_get_contents($filename);
