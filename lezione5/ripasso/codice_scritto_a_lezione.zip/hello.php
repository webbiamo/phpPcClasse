<?php

//echo "Hello\n";

//print_r($argc) .    "\n";
//print_r($argv) .    "\n";

if($argv[1]=='ciao'){
    echo "ciao anche a te amore mio\n";
} else {
    echo "perchè non mi saluti?\n";
}

