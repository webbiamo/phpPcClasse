<?php

echo '<pre>';

print_r($_GET);
print_r($_REQUEST);
print_r($_POST);
