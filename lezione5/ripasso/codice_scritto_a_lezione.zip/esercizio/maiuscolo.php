<?php
echo strtoupper($_POST['testo']);

print_r($_REQUEST);